#include <iostream>
#include "dungeon.h"
#include <string>
//may put in sep func
#include "character/playerRace/drow.h"
#include "character/playerRace/goblin.h"
#include "character/playerRace/troll.h"
#include "character/playerRace/vampire.h"


using namespace std;

bool topWallBottomWall(const string & a){
	int i = 1;
	int end = a.size();
	
	if(a[0] != '|') return false;
	if(a[end - 1] != '|') return false;
	
	while(i < end - 1){
		if(a[i] != '-'){
			return false;
		}
		++i;
	}
	
	return true;
}

Dungeon::Dungeon(ifstream &mapFile, bool whatGen):randGen{whatGen}{
	string floorLine;
	int i = 0;
	
	//load a map File in
	while(getline(mapFile, floorLine)){
		
		if(topWallBottomWall(floorLine)){
			FloorMaps.emplace_back(vector<string>());
			FloorMaps.at(i).emplace_back(floorLine);
			
			getline(mapFile, floorLine);
			
			int j = 1;
			while(!topWallBottomWall(floorLine)){
				FloorMaps.at(i).emplace_back(floorLine);
				getline(mapFile, floorLine);
				
				++j;
				
				
			}
		
			FloorMaps.at(i).emplace_back(floorLine);
			
			++i;
		}
		
	}
	/*
	for(auto floor: FloorMaps){
		for(auto j : floor){
			cout<<j<<endl;
		}
	}*/
	level = 0;
	td = new TextDisplay(FloorMaps.at(level));
	
	currentFloor = new Floor(FloorMaps.at(level), td, randGen);
	
	
	//for now just use drow
	Cell* tmp = currentFloor->genPlayerLoc();
	Coordinate *tmpCoord = tmp->getPos();
	//want this line out###########################################################################################################################################
	player = new Drow(*tmpCoord, *tmp);
	tmp->setCharacter(player);
	
	nextFloorLoc = currentFloor->genStairCase();
	
	currentFloor->genFloor();
	
	
	++level;
	
}

//determines if the cmd was a direction
bool isDirection(string cmd){
	return cmd == "no" ||cmd == "so" || cmd == "ea" || cmd == "we" || 
			cmd == "ne" || cmd == "nw" || cmd == "se" || cmd == "sw";
}

bool Dungeon::play(){
	string cmd = "";
	
	
//	system("clear");
	bool updatePieces;
	bool freeze = false;
	int i = 1;
	while(cmd != "q"){
		updatePieces = true;
		currentFloor->refresh();
		td->print();
		player->printStats();
		cout<<"Turn: "<<i<<" | Floor: "<<level<<endl;
		cout<<"command: ";
		cin>>cmd;
		
		if(isDirection(cmd)){
			player->move(cmd);
			
			Coordinate curCoord = player->getPos();
			cout<<curCoord.getX()<<" "<<curCoord.getY()<<endl;
		}
		else if(cmd == "u"){//use potion
			cin>>cmd;
			
			if(isDirection(cmd)) player->usePot(cmd);
			
		}
		else if(cmd == "a"){ //attack
			cin>>cmd;
			if(isDirection(cmd)) player->attackInDir(cmd);
		}
		else if(cmd == "n"){//auto next floor
			if(level + 1 == 6) victory();
			nextFloor();
			
		}
		else if(cmd == "f"){
			freeze = !freeze;
		}
		else if(cmd == "r"){
			reset();
			updatePieces = false;
			i = 0;
		}
		
		if(*nextFloorLoc == (player->getPos())){
			nextFloor();
			updatePieces = false;
		}
		
//		currentFloor->cleanup();
		if(updatePieces){
			currentFloor->reactEnemies(player);
			if(!freeze) moveEnemies();
		}
		if(player->getPos() == *nextFloorLoc){
			if(level + 1 == 6) victory();
			cout<<"next floor";
			nextFloor();
		}
//		system("clear");
		++i;
	}
}

void Dungeon::chooseChar(){
	
}


void Dungeon::moveEnemies(){
	currentFloor->moveEnemies();
}

void Dungeon::nextFloor(){
	
	//setup new floor
	td = new TextDisplay(FloorMaps.at(level));
	delete currentFloor;
	currentFloor = new Floor(FloorMaps.at(level), td, randGen);
	
	//set player position
	Cell* tmp = currentFloor->genPlayerLoc();
	player->setCell(tmp);
	tmp->setCharacter(player);
	
	//generates floor
	nextFloorLoc = currentFloor->genStairCase();
	currentFloor->genFloor();
	
	player->remStatEffects();
	++level;
}

void Dungeon::victory(){
	system("clear");
	
	cout<<"YAY YOU WON OR SOMETHING"<<endl;
	
	throw "asdf";
	//cout<<player->get
}

void Dungeon::reset(){
	td = new TextDisplay(FloorMaps.at(level));
	
	currentFloor = new Floor(FloorMaps.at(0), td, randGen);
	
	
	//for now just use drow
	Cell* tmp = currentFloor->genPlayerLoc();
	Coordinate *tmpCoord = tmp->getPos();
	//want this line out###########################################################################################################################################
	player = new Drow(*tmpCoord, *tmp);
	tmp->setCharacter(player);
	
	nextFloorLoc = currentFloor->genStairCase();
	
	currentFloor->genFloor();
	
	level = 1;
}
/*
void Dungeon::moveChar(Direction dir){
	
}

void Dungeon::usePot(Direction dir){
	
}

void Dungeon::attack(Direction dir){
	
}

void Dungeon::magic(Direction dir){
	
}
*/
