#ifndef SHADE_H
#define SHADE_H
#include "playerrace.h"


class Shade : public PlayerRace {
public:
	Shade(Coordinate &p, Cell &c);
};


#endif
