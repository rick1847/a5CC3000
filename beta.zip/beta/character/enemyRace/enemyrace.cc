#include "enemyrace.h"


EnemyRace::EnemyRace(Stats &s, Stats &bs, Coordinate &p, Cell &c) : Character(s, bs, p, c)
{}

EnemyRace::~EnemyRace() {
}
