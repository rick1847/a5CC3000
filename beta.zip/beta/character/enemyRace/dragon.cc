#include "dragon.h"
#include "../../item/gold/dhoard.h"

Dragon::Dragon(Coordinate &p, Cell &c, DragonHoard &dh) : 
	EnemyRace(*(new Stats(150, 150, 20, 20)), *(new Stats(150, 150, 20, 20)), p, c), stash(&dh) 
{
	dh.addGuardian(*this);
}

char Dragon::getAvatar() {
	return 'D';
}

void Dragon::move() {
	//this is supposed to do nothing
}

#include <iostream>
using namespace std;
void Dragon::setInactive(){
	cell->setCharacter(nullptr);
	cout<<cell->getPos()->getX()<<cell->getPos()->getY()<<endl;
	cell = nullptr;
	
	//dragon unique stuff
	stash->notifyDeath();
	stash = nullptr;
	
	active = false;
}

void Dragon::attack(Character &who){
	//if something is next to the dragon or its hoard attack it
	if(oneTileAway(who.getPos(), getPos()) || oneTileAway(who.getPos(), stash->getPos())){
		who.takeHit(*this);
		who.printStats();
	}
}
