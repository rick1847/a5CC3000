#include "character.h"
#include <cstdlib>
#include <string>

#include<iostream>
using namespace std;

string whatDir(){
	
	int whichDir = rand() % 8;
	if(whichDir == 0){
		return "no";
	}
	else if(whichDir == 1){
		return "so";
	}
	else if(whichDir == 2){
		return "ea";
	}
	else if(whichDir == 3){
		return "we";
	}
	else if(whichDir == 4){
		return "ne";
	}
	else if(whichDir == 5){
		return "nw";
	}
	else if(whichDir == 6){
		return "se";
	}
	else if(whichDir == 7){
		return "sw";
	}
	
	//should never reach here
	return "";
	
}

Character::Character(Stats &s, Stats &bs, Coordinate &p, Cell &c) : stats(&s), baseStats(&bs), position(&p), cell(&c)
{}

Character::~Character() {
	delete stats;
	delete baseStats;
}

void Character::specialEffect(Vampire &to) {
	(void)to;
}

void Character::specialEffect(Goblin &to) {
	(void)to;
}

void Character::specialEffect(Drow &to) {
	(void)to;
}

void Character::specialEffect(Character &to) {
	(void)to;
}

void Character::receiveEffect(Character &from) {
	from.specialEffect(*this);
}

char Character::getAvatar() {
	return '.';
}

void Character::attack(Character &who) {
	//cout<<"I work"<<endl;
	//default behaviour, if an enemy is one tile away attack it
	if(oneTileAway(who.getPos(), getPos())){
		who.takeHit(*this);
		who.printStats();
	}
}

void Character::takeHit(Character &from) {
	double c100 = 100;
	int dmg = ceil(c100 / (c100 + stats->getDEF()) * from.getStats().getATK());
	stats->addHP(-dmg);
	
	printStats();
	
	if(stats->getHP() < 1) this->setInactive();
}

Stats &Character::getStats() {
	return *stats;
}

Stats &Character::getBaseStats() {
	return *baseStats;
}

void Character::changeStats(Stats &newS) {
	delete stats;
	stats = &newS;
}

void Character::changeCell(Cell *whatCell){
	cell = whatCell;
}
//NOT IMPELEMENTED YET, MUST BE OVERRIDDEN FOR EACH CONCRETE CLASS
void Character::die(){
	
}
	//NOT IMPLEMENTED YET, MUST BE OVERRIDDEN FOR EACH CONCRETE CLASS

void Character::move(){

	string dir = whatDir();
	if(cell){
		cell->send(dir);
		position = cell->getPos();
	}
}

Coordinate Character::getPos(){
	if(cell) return *(cell->getPos());
	else return Coordinate{-10, -10};
}

void Character::printStats(){
	cout<<this->getAvatar()<<"-> ";
	cout<<"Health: "<<stats->getHP()<<"/"<<stats->getMaxHP()<<"|";
	
	cout<<"Attack: "<<stats->getATK()<<"|";
	cout<<"Defense: "<<stats->getDEF()<<"|";
	cout<<"Gold: "<<stats->getGold()<<"|";
	cout<<"Position: ("<<position->getX()<<" "<<position->getY()<<")"<<endl;
}

bool Character::isPlayable(){
	return false;
}

bool Character::getActive(){
	return active;
}

void Character::setInactive(){
	//remove references
	cell->setCharacter(nullptr);
	cell = nullptr;
	position = nullptr;
	
	active = false;
}
	
