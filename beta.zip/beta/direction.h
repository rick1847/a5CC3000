enum class Direction {N, NE, E, SE, S, SW, W, NW};
